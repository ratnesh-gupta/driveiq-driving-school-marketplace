# Roadmap Update: Feature Positioning & Phase Clarity

**Version:** 1.0  
**Date:** January 2026  
**Status:** Strategic Clarification  
**Purpose:** Align feature positioning with reality of current roadmap  

---

## Executive Summary

This document clarifies the positioning and phase assignment of key features based on strategic review:

1. **Geo-Aware Module** → Informational pages (separate from geo search)
2. **School Comparison Engine** → Already built on public pages (not a Phase feature)
3. **Google Business Integration** → Phase 4+ (multi-step rollout)
4. **Geo Search** → Core Phase 1 differentiator (radius + ranking)

---

## Feature Positioning Clarification

### Feature 1: Geo-Aware (Driving Rules & Government Info)

**Current Misconception:**
- Confused with Geo Search (location-based school discovery)
- Positioned as Phase 1–2 delivery

**Actual Purpose:**
- **Informational content** for learners about driving rules, government processes, RTO info
- **Educational**, not operational
- Builds trust and positions platform as mobility knowledge authority
- Supports organic SEO (learners searching for "RTO near me", "driving license process")

**Positioning:** Learner-facing informational layer

**Phase Assignment:** 
- **Phase 2 (Trust & Verification)** — as ancillary educational content
- Can be built in parallel with Phase 2 or deferred to Phase 2.5
- **Not blocking** any core marketplace functionality

**Delivery Format:**
- Animated, informative pages on public site
- Geo-aware (shows rules for selected city/state)
- Examples:
  - `/driving-license-guide` → Step-by-step learner license process
  - `/rto-offices-pune` → List of RTO offices with timings
  - `/Maharashtra-traffic-rules` → Vehicle/helmet/speed regulations
  - `/pune-driving-schools-faq` → Common questions about training

**Why Separate from Geo Search?**
- Geo Search (Phase 1) = functional discovery → "Find schools near me"
- Geo-Aware (Phase 2) = informational content → "Understand rules + processes"
- Different user intent, different value prop, different build timeline

---

### Feature 2: School Comparison Engine

**Current Status:**
- **Already built on public pages** (per your clarification)
- Working in marketplace (side-by-side school comparison)
- Not a future Phase deliverable

**Why It's NOT a Phase Feature:**
- Already shipped and operational
- Users can compare schools during search/browsing
- Comparison table, shareable links, attributes all present

**If Enhancement Needed (Future):**
- Smart badges ("Best Value", "Best Rated")
- Programmatic comparison SEO pages
- AI-powered recommendations
- All post-MVP territory

**Current Scope:** ✓ Complete and maintained as part of public marketplace

---

### Feature 3: Google Business Integration

**Current Misconception:**
- Positioned as single Phase 4 feature
- Assumed as monolithic integration

**Actual Reality:**
- **Multi-step rollout across multiple phases**
- Not all Google Business features launch simultaneously
- Progressive value delivery

**Phased Rollout:**

#### Phase 3 (School Management) Preparation
```
✓ API key infrastructure (for future integrations)
✓ Webhook endpoint setup (for receiving data from Google)
✓ School settings foundation
✗ Google Business connection not yet available
```

#### Phase 4a (Monetization — Early)
```
✓ Google Business connection (OAuth)
✓ Profile sync (get school data from Google)
✓ Basic profile management (read/write school hours, description)
✓ Photo upload to Google Business
✗ Advanced features (reviews, posts) defer to Phase 4b
```

#### Phase 4b (Monetization — Later)
```
✓ Review management (view, reply to reviews)
✓ Google Posts (create, schedule)
✓ Visibility score calculation
✓ Competition insights (basic)
✗ AI reply suggestions defer to future
```

#### Phase 10+ (Future Enhancements)
```
✓ AI content generation for posts
✓ Lead attribution from Google
✓ Multi-location management (franchises)
✓ Advanced analytics
```

**Why Multi-Step?**
- Complexity requires careful integration
- Schools need stable core (Phase 3) before adding Google sync
- Early wins (basic sync + photo upload) deliver value
- Advanced features (reviews, posts) come after core is solid

---

## Updated Roadmap Overview

### Phase 0: MVP Stabilization (2-4 weeks)
**Current → Production-Safe**
- Backend auth + RBAC
- API rate limiting
- Inquiry field expansion
- Event logging

**Exit:** Protected APIs, abuse controls active

---

### Phase 1: Geo-Intelligent Search (3-5 weeks) ⭐ CORE DIFFERENTIATOR
**Goal:** Nearest school discovery (MVP)

```
Scope:
  ✓ PostGIS + radius search (2km, 5km, 10km)
  ✓ Geo ranking (distance + rating + verified + premium)
  ✓ Geolocation consent + near-me flow
  ✓ Google Maps display on school profile
  ✓ Marketplace can be discovered by distance/radius

Scope OUT:
  ✗ Geo-Aware informational pages (→ Phase 2)
  ✗ Comparison engine enhancements (already built)
  ✗ Google Business (→ Phase 4)

Outcome:
  Schools discoverable by proximity
  Users can find training near them
  Core marketplace differentiator vs. Google Business
```

---

### Phase 2: Trust & Verification (2-3 weeks)
**Goal:** Build confidence in marketplace

```
Scope:
  ✓ Verification model (phone, business, location, premium)
  ✓ Review eligibility enforcement
  ✓ Abuse reporting + moderation
  ✓ Trust badges in listings
  
Scope IN (Ancillary):
  ✓ Geo-Aware informational pages (can be added here)
    - Government rules/resources
    - RTO office locator
    - License process guides
    - Animated, educational

Scope OUT:
  ✗ Google Business integration (→ Phase 4)
  ✗ School Management UI (→ Phase 3)

Outcome:
  Learners trust schools
  Schools verified + badged
  Knowledge base builds platform authority
```

---

### Phase 3: School Management (4-6 weeks) ⭐ FOUNDATION
**Goal:** School operations control (see PRD-School-Management.md)

```
Scope:
  ✓ School profile management (marketplace-facing)
  ✓ Settings configuration (hours, service areas, contact)
  ✓ Operations dashboard
  ✓ Admin/team user management
  ✓ Subscription tier management
  ✓ Audit logging

Scope OUT:
  ✗ Instructor management UI (→ Phase 5)
  ✗ Learner management (→ Phase 7)
  ✗ Google Business (→ Phase 4)
  ✗ Geo-Aware pages (if not done in Phase 2)

Outcome:
  Schools control their destiny
  Recurring engagement + admin delegation
  Foundation for instructor/learner modules
  Subscription model ready for monetization
```

---

### Phase 4: Monetization & Google Business Integration (3-5 weeks)
**Goal:** Revenue stream + school growth tools

```
Phase 4a: Featured Listings (Weeks 1-2)
  ✓ Listing tier model (basic/featured/premium)
  ✓ Premium ranking controls
  ✓ Admin featured slot management
  ✓ School subscription visibility + renewal

Phase 4b: Google Business — Early Integration (Weeks 2-3)
  ✓ Google Business connection (OAuth)
  ✓ Profile sync (read/write school info)
  ✓ Photo upload to Google Business
  ✓ Basic profile optimization

Phase 4c: Google Business — Reviews & Posts (Weeks 3-4, optional defer)
  ✓ Review management (view, reply)
  ✓ Google Posts creation/scheduling
  ✓ Visibility score dashboard
  ✓ Competition insights

Scope OUT:
  ✗ Instructor management (→ Phase 5)
  ✗ Learner management (→ Phase 7)
  ✗ AI features (→ Phase 10+)

Outcome:
  Schools upgrade subscription (revenue model)
  Featured listings visible to learners
  Google Business optimized from one platform
  Additional SaaS value prop
```

---

### Phase 5: Instructor Management (4-6 weeks) ⭐ SECOND PILLAR
**Goal:** School trainer team operations

```
Scope:
  ✓ Instructor profiles (personal, credentials, documents)
  ✓ Instructor authentication (login)
  ✓ School admin instructor management (roster, invite)
  ✓ Instructor dashboard (overview, learners, sessions read-only)
  ✓ Public marketplace integration (trainer cards, ratings)

Scope OUT:
  ✗ Scheduling UI (→ Phase 6)
  ✗ Learner management (→ Phase 7)
  ✗ Availability management (→ Phase 6)

Outcome:
  Schools can onboard trainers
  Learners see trainer profiles + ratings
  Trainer authentication ready for Phase 6
  Trainer marketplace visibility high
```

---

### Phase 6: Instructor Advanced Operations (4-5 weeks)
**Goal:** Scheduling + capacity management

```
Scope:
  ✓ Training schedule (calendar, session creation)
  ✓ Conflict detection (no double-booking)
  ✓ Availability management (working days, leave)
  ✓ Attendance tracking
  ✓ Session notes + feedback

Outcome:
  Conflict-free scheduling
  Trainer workload visible
  Leave management automated
  Session history complete
  Ready for learner assignment (Phase 7)
```

---

### Phase 7: Learner Management (4-6 weeks) ⭐ THIRD PILLAR
**Goal:** Learner enrollment + lifecycle

```
Scope:
  ✓ Learner profiles (personal, license info)
  ✓ Lead → Learner conversion (inquiry → enrollment)
  ✓ Document management (uploads, expiry tracking)
  ✓ Learner assignment (assign learner → trainer → vehicle)
  ✓ Learner portal (basic view of status)

Scope OUT:
  ✗ Progress tracking (→ Phase 8)
  ✗ Messaging (→ Phase 9)

Outcome:
  Learners enrolled post-inquiry
  Documents collected
  Trainer assignments created
  Ready for training sessions (Phases 6, 8)
```

---

### Phase 8: Learner Progress & Attendance (3-4 weeks)
**Goal:** Training progress tracking

```
Scope:
  ✓ Training schedule (learner view)
  ✓ Progress tracking (skill %, lessons completed)
  ✓ Session history (past sessions visible)
  ✓ Driving test tracking
  ✓ Certificate download

Outcome:
  Learner transparency into training journey
  School visibility into completion rates
  Metrics for Phase 10 analytics
```

---

### Phase 9: Internal Messaging (2-3 weeks)
**Goal:** Replace WhatsApp dependency

```
Scope:
  ✓ Messaging system (school ↔ trainer, trainer ↔ learner, school ↔ learner)
  ✓ Message history
  ✓ Email notifications

Outcome:
  Key communications in-platform
  Audit trail for compliance
  Reduced WhatsApp chatter
```

---

### Phase 10: Analytics & Insights (3-4 weeks)
**Goal:** Data-driven visibility

```
Scope:
  ✓ School dashboard analytics (leads, conversions, completion %)
  ✓ Instructor performance (sessions, ratings, completion)
  ✓ Learner cohort analytics (progress, outcomes)

Outcome:
  Schools have actionable data
  Platform understands what works
  Data-driven product improvements
```

---

## Feature Matrix: Which Phase, Which User?

| Feature | Phase | School | Instructor | Learner | Public |
|---------|-------|--------|-----------|---------|--------|
| **Marketplace Discovery** | 0 | - | - | ✓ | ✓ |
| Geo Search (Radius) | 1 | - | - | ✓ | ✓ |
| Geo Ranking | 1 | - | - | ✓ | ✓ |
| Trust Badges | 2 | - | - | ✓ | ✓ |
| Geo-Aware Pages | 2 | - | - | ✓ | ✓ |
| **School Profile Management** | 3 | ✓ | - | - | ✓ |
| School Settings | 3 | ✓ | - | - | - |
| Operations Dashboard | 3 | ✓ | - | - | - |
| Team Management | 3 | ✓ | - | - | - |
| **Featured Listings** | 4 | ✓ | - | - | ✓ |
| Google Business (Basic) | 4a | ✓ | - | - | - |
| Google Business (Reviews/Posts) | 4b | ✓ | - | - | - |
| **Instructor Profile** | 5 | ✓ | ✓ | - | ✓ |
| Instructor Login | 5 | - | ✓ | - | - |
| Trainer Ratings | 5 | ✓ | ✓ | ✓ | ✓ |
| **Scheduling** | 6 | ✓ | ✓ | - | - |
| Availability Management | 6 | ✓ | ✓ | - | - |
| Leave Management | 6 | ✓ | ✓ | - | - |
| **Learner Enrollment** | 7 | ✓ | - | ✓ | - |
| Document Management | 7 | ✓ | - | ✓ | - |
| Learner → Trainer Assignment | 7 | ✓ | - | ✓ | - |
| **Progress Tracking** | 8 | ✓ | ✓ | ✓ | - |
| Session History | 8 | ✓ | ✓ | ✓ | - |
| **Messaging** | 9 | ✓ | ✓ | ✓ | - |
| **Analytics** | 10 | ✓ | ✓ | - | - |

---

## GTM Launches Reconsidered

### Launch 1: Marketplace MVP (Week 12, End of Phase 3)
```
Learners can:
  ✓ Discover schools (search, geo, filters)
  ✓ See school profiles (ratings, reviews, photos)
  ✓ Verify school legitimacy (badges)
  ✓ Learn about driving (Geo-Aware content)
  ✓ Submit inquiries

Schools can:
  ✓ Receive leads
  ✓ Manage profile (photos, hours, service areas)
  ✓ Manage team (invite admins)
  ✓ View dashboard (key metrics)
  ✓ Know subscription status

Platform:
  ✓ Sustainable lead generation
  ✓ School stickiness (they manage profile daily)
  ✓ Recurring engagement model in place

Why this works:
  - Complete enough for schools to see ongoing value
  - Marketplace viability proven
  - School Management foundation solid
  - Ready to add instructor/learner layers
```

### Launch 2: Instructor Management (Week 28, End of Phase 6)
```
Schools can additionally:
  ✓ Onboard instructors
  ✓ Assign learners to trainers
  ✓ Manage training schedules (no conflicts)
  ✓ Track trainer performance

Instructors can:
  ✓ Login and view their learners
  ✓ See their schedule
  ✓ Submit session notes

Learners can:
  ✓ See trainer profiles before registering
  ✓ Track sessions (on horizon)

Platform:
  ✓ Supports mid-market schools (3+ trainers)
  ✓ Trainer visibility highest on platform
  ✓ Scheduling complexity solved

Why this works:
  - Schools with multiple trainers need coordination
  - Prevents trainer chaos / WhatsApp overload
  - Trainer cards on public marketplace drive trust
```

### Launch 3: Full Platform (Week 50, End of Phase 10)
```
Schools can additionally:
  ✓ Manage complete learner lifecycle
  ✓ Track progress per learner
  ✓ Manage documents + compliance
  ✓ Run internal messaging (no WhatsApp needed)
  ✓ View comprehensive analytics

Learners can:
  ✓ Register post-inquiry
  ✓ Track training progress
  ✓ View documents + certificates
  ✓ Message trainer

Platform becomes:
  ✓ Operating System for Driving Schools
  ✓ Replaces spreadsheets, notebooks, WhatsApp
  ✓ Complete SaaS platform (recurring revenue)

Why this works:
  - Schools adoption highest
  - Learners experience complete
  - Platform is now truly sticky (daily usage)
```

---

## Implementation Priority

### HIGH Priority (Block Nothing Else)
1. ✓ Phase 0: Auth + RBAC (security gate)
2. ✓ Phase 1: Geo Search (core differentiator)
3. ✓ Phase 3: School Management (foundation)

### MEDIUM Priority (Value-Add but Deferrable)
4. Phase 2: Trust + Geo-Aware (confidence builder)
5. Phase 4: Monetization + Google Business (revenue)

### SEQUENTIAL (Cannot Start Until Prior Phase Done)
6. Phase 5: Instructors (depends on Phase 3)
7. Phase 6: Scheduling (depends on Phase 5)
8. Phase 7: Learners (depends on Phase 6)
9. Phase 8: Progress (depends on Phase 7)
10. Phase 9: Messaging (nice-to-have, not critical path)
11. Phase 10: Analytics (reporting layer, not critical path)

---

## Open Questions Resolved

### Q1: Where does Geo-Aware fit?
**A:** Phase 2 as informational layer. Not phase-blocking. Separate from Geo Search.

### Q2: Is Comparison Engine a Phase?
**A:** No. Already built. Maintain as part of marketplace. Enhancements defer to post-MVP.

### Q3: When does Google Business launch?
**A:** Phase 4, multi-step. Basic (4a) before advanced (4b).

### Q4: Should School Management include instructor UI?
**A:** No. Phase 3 = school profile/settings/admin. Phase 5 = instructor roster (separate).

### Q5: When can we start Phase 5?
**A:** Only after Phase 3 stable + Phase 4 revenue model clear.

---

## Conclusion

This update clarifies positioning and roadmap integrity:

✓ Geo-Aware = Educational, not operational  
✓ Comparison = Already shipped, not a phase  
✓ Google Business = Multi-step rollout (4a, 4b, 10+)  
✓ Phase boundaries now crisp and sequenced  
✓ GTM launches aligned with value delivery  
✓ Instructor/learner integration dependencies clear  

**Ready to execute:** Phase 0 → Phase 1 → Phase 2/3 (parallel) → Phase 4 → Phase 5+
