# PRD – School Management System

## Foundational Operations Platform for Driving Schools

**Version:** 1.0  
**Phase:** Phase 3 (Weeks 13–18)  
**Status:** Foundational Module  
**Dependency:** Phase 0 (Auth), Phase 1 (Geo), Phase 2 (Trust)  
**Unlocks:** Phase 4 (Monetization), Phase 5 (Instructor Management), Phase 7 (Learner Management)

---

## Executive Summary

The School Management System is the **operational foundation** of the DriveIQ platform. It enables driving schools to:

- Maintain complete, verified profiles for marketplace discovery
- Configure business settings (timings, service areas, contact methods)
- Manage admin users and team permissions (RBAC)
- View operational dashboards and KPIs
- Track subscription tier and billing
- Maintain audit trail for compliance

This module establishes **school-centric data ownership** required before instructor management (Phase 5) and learner management (Phase 7) can be built.

---

## Product Vision

Transform schools from **passive marketplace listings** to **active platform operators** with complete control over:

```text
Profile Visibility
    ↓
Operations Configuration
    ↓
Team Access Control
    ↓
Business Intelligence
    ↓
Subscription Management
```

---

## Business Objectives

### Primary
- Increase school stickiness and daily platform usage
- Enable schools to maintain profile quality autonomously
- Create recurring SaaS revenue (Phase 4)
- Reduce marketplace support burden (schools self-serve)

### Secondary
- Build foundation for instructor/learner management
- Prepare for multi-branch expansion (future)
- Establish audit trail for regulatory compliance
- Support schools converting to franchise/enterprise models

---

## Problem Statement

**Current State:**
Schools today are passive participants:
- Create listing, receive leads
- Minimal control over profile after creation
- No visibility into operational metrics
- No way to manage team access
- No audit trail for compliance

**Result:**
- Schools deprioritize platform (leads alone aren't enough)
- Profile stagnates (outdated photos, hours, service areas)
- No recurring engagement
- Schools remain commoditized on directory sites

---

## Target Users

### School Owner
- Owns the business
- Sets policies and configuration
- Views business intelligence
- Manages admins and team
- Upgrades subscription tier

### School Manager/Admin
- Operates day-to-day
- Updates profile and settings
- Manages inquiries (Phase 2)
- Views dashboard metrics
- Cannot change subscription or add admins (permission-based)

### Platform Admin
- Approves/flags schools
- Manages featured listings (Phase 4)
- Views cross-school analytics
- Manages support escalations

---

## Module Scope: What's IN vs. OUT

### ✅ Phase 3 School Management INCLUDES

1. **School Profile Management**
2. **School Settings Configuration**
3. **Operations Dashboard**
4. **Admin/Team User Management with RBAC**
5. **Subscription Tier Management**
6. **Audit Logging**

### ❌ Phase 3 School Management EXCLUDES

- Instructor Management (→ Phase 5)
- Learner Management (→ Phase 7)
- Google Business Integration (→ Phase 4, multi-step)
- Scheduling/Calendar (→ Phase 5/6)
- Messaging System (→ Phase 9)
- Advanced Analytics (→ Phase 10)

**Important:** Phase 3 prepares data structures and API contracts for instructors/learners but does NOT build UI or workflows for managing them.

---

## 1. School Profile Management

Schools maintain a marketplace-facing profile visible in:
- Search results
- Locality pages
- Detail page (prospect view)
- Comparison engine

### 1.1 Profile Components

#### Business Information (Editable by Owner/Admin)

```text
Legal Business Name (required)
Local Display Name (optional — used in listings)
Description (max 500 chars)
Website URL
Business Email
Business Phone (primary contact)
Registration Number / License Number
Years in Business
```

#### Media Assets (Uploaded by Owner/Admin)

```text
Logo (required for marketplace visibility)
   - 1:1 square PNG/JPG
   - min 200x200px
   - used in listings, detail page

Banner Image (optional)
   - 16:9 aspect ratio
   - min 1200x675px
   - used on detail page hero

Profile Photos (up to 10)
   - JPG/PNG
   - used in photo carousel
   - categorized: classroom, vehicle, exterior, instructor (future)

Instructor Profile Photos (stored here, managed by Phase 5)
   - Reserved for Phase 5 instructor module
   - Schema exists but not UI in Phase 3
```

#### Address & Service Coverage (Required)

```text
Primary Address
   - Street
   - City (Pune initially)
   - Locality (dropdown, pre-filled options)
   - Postal Code
   - GPS Coordinates (auto-filled from address or manual)

Service Areas
   - Multi-select from Pune localities (Baner, Hinjewadi, Wakad, etc.)
   - Used for geo-search filtering
   - Updated by owner/admin

Service Radius
   - Pickup/drop service radius in km (numeric input)
   - Default: 5 km
   - Used in geo ranking and "nearest school" calculations
```

#### Verification Status (Read-only, Managed by Platform)

```text
Verified Badge Status
   - values: unverified, phone_verified, business_verified, fully_verified
   - managed by platform admin (Phase 2 trust system)
   - displayed on school detail and listings
```

#### Profile Completeness Score

Schools see a progress indicator:

```text
Profile Completeness: 72%

Missing Items:
- [ ] Business Website
- [ ] 3+ Profile Photos
- [ ] Service Area Description
- [ ] Operating Hours

Impact: Incomplete profiles may rank lower in search.
[Add Missing Details]
```

### 1.2 Profile Update Workflow

**Owner/Admin can edit:**
- Business name, description
- Contact methods
- Address and service areas
- Operating hours
- Media assets (upload/replace/delete)
- Service radius

**Owner/Admin cannot edit:**
- Verification status (platform-controlled)
- Registration/license (platform-verified)
- Marketplace rating (derived from reviews)

**Update Audit:**
- All profile changes logged to audit trail
- Timestamp, user ID, old/new values recorded
- Visible to school owner in audit log

### 1.3 Profile Visibility in Marketplace

Schools choose:
- **Public:** visible in search/locality pages
- **Unlisted:** visible via direct link only
- **Hidden:** not visible (subscription paused or school inactive)

---

## 2. School Settings Configuration

Schools customize operational parameters without code changes.

### 2.1 Operating Hours & Availability

```text
Days of Operation
   - Select: Mon, Tue, Wed, Thu, Fri, Sat, Sun
   - For each day, set opening time and closing time
   - Example: Mon-Fri 9am-6pm, Sat 9am-2pm, Closed Sun

Holiday/Closure Dates
   - Add closure periods (date ranges)
   - Example: Diwali closure, maintenance week
   - Used to prevent scheduling during closed periods (Phase 5)

Batch Timings (Offered)
   - Checkboxes for convenience filters:
     ☐ Morning batches (e.g., 6-8am)
     ☐ Afternoon batches (e.g., 2-4pm)
     ☐ Evening batches (e.g., 4-7pm)
     ☐ Weekend batches
   - Displayed on profile and used in search filters
```

### 2.2 Vehicle Types & Training Options

```text
Vehicle Types Offered
   - ☐ Car Manual Transmission
   - ☐ Car Automatic Transmission
   - ☐ Two-Wheeler (Motorcycle)
   - ☐ Two-Wheeler (Scooter)
   - ☐ Heavy Vehicle (Commercial)

Training Features
   - ☐ Simulator Training Available
   - ☐ Pickup/Drop Service Available
   - ☐ Women-Only Training Batches
   - ☐ License Assistance Provided
   - ☐ Free Re-Test Policy

Languages Offered
   - Multi-select: Hindi, English, Marathi, Gujarati, etc.
   - Stored for Phase 5 (instructor language matching)
```

### 2.3 Contact & Communication Preferences

```text
Primary Contact Method
   - Select: Phone, Email, WhatsApp, Callback Form

Contact Details
   - Phone (linked to school profile)
   - Email (linked to school profile)
   - WhatsApp Business Number (optional)
   - Preferred communication time window

Notification Preferences
   - ☐ Email notification on new inquiry
   - ☐ Email digest (daily/weekly)
   - ☐ SMS on new inquiry (future)
   - ☐ In-app notifications enabled

Do Not Disturb Hours
   - Set quiet hours (e.g., after 8pm, before 8am)
   - Inquiries still recorded but notifications delayed
```

### 2.4 API Configuration (For Integration, Phase 4+)

```text
API Keys (Generated & Managed)
   - Live API Key
   - Test API Key
   - Regenerate option (invalidates old key)

Webhook Endpoints (Future)
   - URL to receive inquiry/lead events
   - Endpoint verification via challenge
   - Event log (sent, failed, retried)
   - Used for CRM/ERP integration

Integrations (Future)
   - Google Business Profile (Phase 4)
   - CRM (Salesforce, Zoho, etc. — future)
   - Scheduling tools (future)
```

### 2.5 Compliance & Data Settings

```text
Privacy Policy URL
   - Link to school's privacy policy
   - Required for GDPR-like compliance

Data Retention
   - How long to keep learner data (dropdown: 6mo, 1yr, 2yr, custom)
   - Applied when learner relationship ends

GDPR Consent
   - Checkbox: School confirms compliance with data protection laws
   - Stored in audit log
```

---

## 3. Operations Dashboard

Schools access a unified dashboard showing key metrics and status.

### 3.1 Dashboard Layout (School Owner/Admin View)

**Header Section**
```text
School Name | Profile Completeness: 72% | Subscription: Growth Plan (Expires: 30 Jan 2026)
[Manage Profile] [Upgrade Plan] [Support]
```

**Quick Stats Cards (Row 1)**
```text
┌─────────────────────────────────────────────────────────────┐
│ Total Inquiries    │ This Month   │ Conversion Rate │ Rating  │
│ 45 (↑ 12%)        │ 12 new       │ 22% (target: 25%)│ 4.7    │
└─────────────────────────────────────────────────────────────┘
```

**Activity Feed (Row 2)**
```text
Recent Inquiries (Last 7 days)
- 3 new inquiries from Baner locality
- 2 from Hinjewadi
- 1 from Wakad
[View All Inquiries] → (links to inquiry management, Phase 2)
```

**Status Indicators (Row 3)**
```text
Profile Status: ✓ Complete (but see completeness score)
Verification: ⏳ Phone verified (pending business verification)
Subscription: ✓ Active — Growth Plan (₹2999/mo)
Listing Visibility: ✓ Public (visible in search)
```

**Operational Alerts (Row 4)**
```text
⚠ 3 missing profile photos (impacts search ranking)
⚠ Service area coverage incomplete (5/6 localities selected)
ℹ Weekend batch setting enabled but no schedule (Phase 5)
```

**Upcoming Actions (Row 5)**
```text
Subscription renews: 30 Jan 2026 [Manage]
Last profile update: 5 days ago [Edit]
Team members: 2 admins active [Manage Team]
```

### 3.2 Metric Definitions

| Metric | Source | Updated | Visibility |
|--------|--------|---------|-----------|
| Total Inquiries | Inquiry table | Real-time | All admins |
| This Month Inquiries | Inquiry table (filtered) | Real-time | All admins |
| Conversion Rate | (Inquiries converted / Total) % | Daily | Owner/Manager |
| Profile Completeness | Calculated from profile fields | Real-time | All admins |
| Rating (Avg) | Reviews aggregate | Daily | All admins |
| Review Count | Reviews table | Daily | All admins |

---

## 4. Admin & Team Management

Schools can delegate access to team members with role-based permissions.

### 4.1 User Roles & Permissions Matrix

#### Role: School Owner
```text
Permissions:
  ✓ Edit school profile (all fields)
  ✓ Edit school settings
  ✓ View operations dashboard
  ✓ Manage team (add/remove admins)
  ✓ Change subscription tier
  ✓ View audit log
  ✓ View billing/invoices
  ✓ Delete school account
  
Cannot:
  ✗ NOT constrained from any action
```

#### Role: School Manager/Admin
```text
Permissions:
  ✓ Edit school profile (all fields)
  ✓ Edit school settings
  ✓ View operations dashboard
  ✓ View team member list
  ✓ Manage inquiries (Phase 2 onward)
  ✓ View audit log (own actions + read-only)
  
Cannot:
  ✗ Add/remove team members (only owner)
  ✗ Change subscription tier (only owner)
  ✗ View billing/invoices (only owner)
  ✗ Delete school account (only owner)
```

#### Role: Instructor (Phase 5 Onward)
```text
Permissions:
  ✓ View own profile
  ✓ View assigned learners (Phase 7)
  ✓ Edit own availability/hours (Phase 6)
  ✓ Submit session notes (Phase 6)
  
Cannot:
  ✗ Edit school profile
  ✗ Manage other instructors
  ✗ View school settings
  
Note: Phase 3 does not include instructor role/permissions.
      Prepared for Phase 5 integration.
```

### 4.2 Team Member Invitation Workflow

**Owner initiates:**

1. Dashboard → [Manage Team] → [Invite Admin]
2. Enter admin email + select role (Manager or Owner secondary)
3. System sends invitation email with:
   - Personalized message
   - Accept link with token (valid 7 days)
   - Token includes: school_id, invited_email, role, expiry
4. Invitee clicks link → signup page
5. If existing platform user: login → auto-assigned to school
6. If new user: create account → auto-assigned to school

**Owner sees:**
```text
Team Members
┌─────────────────────────────────────────────────┐
│ Email              │ Role       │ Status   │    │
├─────────────────────────────────────────────────┤
│ owner@school.com   │ Owner      │ Active   │ -  │
│ admin1@email.com   │ Manager    │ Active   │ ⋮  │
│ admin2@email.com   │ Manager    │ Pending* │ ⋮  │
└─────────────────────────────────────────────────┘
*Invitation expires in 5 days — [Resend] [Revoke]
```

**Invited admin sees invitation in:**
- Email inbox (with link)
- Platform notification (if already signed up)

### 4.3 Admin Access Control

**In the application:**

```text
Every action by an admin is tagged with:
  - User ID
  - Timestamp
  - Action type (created, updated, deleted)
  - Resource affected (profile, settings, team, etc.)
  - Old/new values (for updates)

Visible to:
  - School owner (all audit logs)
  - Each admin (their own audit logs only)
```

**On API level:**

```text
Every API request requires:
  - Valid session/JWT token
  - Token includes: user_id, school_id, role
  - API checks: does this user have permission for this action?
  - Example: POST /schools/{school_id}/settings
    - Only owner/admin of that school can update
    - Logged to audit trail
```

---

## 5. Subscription Tier Management

Schools can view and manage subscription.

### 5.1 Subscription Status Widget

```text
┌──────────────────────────────────┐
│ Your Plan: Growth (₹2,999/month) │
│ Billing Cycle: Monthly            │
│ Next Renewal: 30 Jan 2026         │
│ Status: ✓ Active                  │
│                                   │
│ [View Invoice] [Upgrade Plan]     │
└──────────────────────────────────┘
```

### 5.2 Plan Upgrade/Downgrade

**Upgrade Flow:**
1. Click [Upgrade Plan]
2. See plan comparison table (features by tier)
3. Select target plan
4. Confirm billing amount (prorated if mid-cycle)
5. Confirm with existing payment method or add new
6. Subscription upgraded immediately
7. Confirmation email sent

**Downgrade Flow:**
1. Click [Change Plan]
2. Select lower tier
3. System warns: "Downgrade effective on next billing date"
4. Features that will be disabled listed
5. Confirm
6. Downgrade scheduled; email sent with effective date

### 5.3 Billing History

Schools see:
```text
Invoice History
┌────────────────────────────────────────┐
│ Date       │ Plan       │ Amount  │    │
├────────────────────────────────────────┤
│ 30 Dec 25  │ Growth     │ ₹2,999  │ ✓  │
│ 30 Nov 25  │ Growth     │ ₹2,999  │ ✓  │
│ 30 Oct 25  │ Basic      │ ₹999    │ ✓  │
└────────────────────────────────────────┘

[Download Invoice] option per row
```

### 5.4 Subscription Tier Mapping (Phase 3 Preview)

**Features by Tier** (detailed pricing doc → Phase 4):

| Feature | Basic | Growth | Professional | Enterprise |
|---------|-------|--------|--------------|-----------|
| Marketplace Listing | ✓ | ✓ | ✓ | ✓ |
| Profile Management | ✓ | ✓ | ✓ | ✓ |
| Team Admins | 1 | 2 | Unlimited | Unlimited |
| Inquiry Management | ✓ | ✓ | ✓ | ✓ |
| Instructor Management | - | - | ✓ | ✓ |
| Learner Management | - | - | - | ✓ |
| Featured Listing (Phase 4) | - | Optional | ✓ | ✓ |
| Google Business (Phase 4) | - | Optional | ✓ | ✓ |
| API Access (Phase 4) | - | - | ✓ | ✓ |
| Priority Support | - | - | - | ✓ |

**Note:** Exact tier names and pricing finalized in Phase 4.

---

## 6. Audit Logging & Compliance

Every action is logged for compliance, debugging, and transparency.

### 6.1 Audit Log Schema

```text
Event Log Table
┌─────────────────────────────────────────────────────────┐
│ timestamp          │ 2026-01-15 14:32:05 UTC            │
│ event_type         │ "school.profile.updated"           │
│ school_id          │ 12345                              │
│ user_id            │ 789 (admin user)                   │
│ action             │ "updated"                          │
│ resource_type      │ "school"                           │
│ resource_id        │ 12345                              │
│ change_summary     │ "Updated service area coverage"    │
│ old_value          │ ["Baner", "Hinjewadi"]            │
│ new_value          │ ["Baner", "Hinjewadi", "Wakad"]   │
│ ip_address         │ 203.0.113.42                       │
│ user_agent         │ "Mozilla/5.0... Chrome/120"        │
└─────────────────────────────────────────────────────────┘
```

### 6.2 Audit Events Captured (Phase 3)

| Event Type | Triggered By | Logged Data |
|-----------|-------------|------------|
| school.created | Platform admin | School ID, owner user ID |
| school.profile.updated | Owner/admin | Field changes, timestamp, user |
| school.settings.updated | Owner/admin | Setting changes, old/new values |
| school.team.invited | Owner | Invited email, role |
| school.team.added | Invitee accept | New admin user ID, role |
| school.team.removed | Owner | Removed user ID, role |
| school.subscription.upgraded | Owner | Old tier, new tier, effective date |
| school.subscription.downgraded | Owner | Old tier, new tier, effective date |
| school.verification.updated | Platform admin | Verification status change |
| school.deleted | Owner | Soft delete, timestamp |

### 6.3 Audit Log Visibility

**School Owner sees:**
- Complete audit log for their school
- All user actions (all admins)
- Filters: date range, event type, user, resource

**School Admin sees:**
- Own actions only (read-only)
- Cannot see other admins' actions

**Platform Admin sees:**
- Cross-school audit logs (for support/investigation)
- Can export logs for compliance

### 6.4 Data Retention

- Audit logs retained for 2 years minimum (configurable per school)
- School owner can request full export for compliance
- Data deletion follows school closure (30-day grace period)

---

## 7. Data Model & API Contracts

### 7.1 School Entity (Extended)

```typescript
interface School {
  id: UUID
  created_at: timestamp
  updated_at: timestamp
  deleted_at: timestamp | null (soft delete)
  
  // Business Identity
  legal_business_name: string
  display_name: string | null
  description: string | null
  website_url: string | null
  business_email: string
  business_phone: string
  registration_number: string | null
  years_in_business: number | null
  
  // Location
  address_street: string
  address_city: string (Pune initially)
  address_locality: string (dropdown reference)
  address_postal_code: string
  latitude: number
  longitude: number
  service_areas: string[] (array of locality keys)
  service_radius_km: number
  
  // Media
  logo_url: string | null
  banner_url: string | null
  photo_urls: string[]
  
  // Operations
  operating_hours_json: OperatingHours
  service_closure_dates: ClosureDate[]
  batch_timings_offered: BatchTiming[]
  vehicle_types_offered: VehicleType[]
  training_features: TrainingFeature[]
  languages_offered: Language[]
  
  // Status & Verification
  status: "active" | "inactive" | "suspended"
  verification_status: "unverified" | "phone_verified" | "business_verified" | "fully_verified"
  is_public: boolean (visible in marketplace)
  
  // Subscription
  subscription_tier_id: UUID (foreign key)
  subscription_start_date: timestamp
  subscription_renewal_date: timestamp
  
  // Meta
  owner_user_id: UUID (foreign key to users table)
  admin_user_ids: UUID[] (array of team member user IDs)
  profile_completeness_score: number (0-100, calculated)
  
  // Inquiry & Lead Stats
  total_inquiries: number (cached, updated daily)
  total_inquiries_this_month: number (cached)
  inquiry_conversion_rate: number (cached %)
}
```

### 7.2 School Settings Entity

```typescript
interface SchoolSettings {
  school_id: UUID (primary + foreign key)
  
  // Contact Preferences
  primary_contact_method: "phone" | "email" | "whatsapp" | "form"
  whatsapp_business_number: string | null
  do_not_disturb_start: time (HH:mm)
  do_not_disturb_end: time (HH:mm)
  
  // Notifications
  email_on_inquiry: boolean
  email_digest_frequency: "daily" | "weekly" | "none"
  sms_on_inquiry: boolean (future)
  in_app_notifications: boolean
  
  // Compliance
  privacy_policy_url: string | null
  data_retention_days: number (180, 365, 730, custom)
  gdpr_compliant: boolean
  
  // API Integration
  api_key_live: string (hashed)
  api_key_test: string (hashed)
  webhook_endpoint_url: string | null
  webhook_verified: boolean
  
  created_at: timestamp
  updated_at: timestamp
}
```

### 7.3 Operating Hours Entity

```typescript
interface OperatingHours {
  monday: { open: time, close: time } | null
  tuesday: { open: time, close: time } | null
  wednesday: { open: time, close: time } | null
  thursday: { open: time, close: time } | null
  friday: { open: time, close: time } | null
  saturday: { open: time, close: time } | null
  sunday: { open: time, close: time } | null
}

interface ClosureDate {
  school_id: UUID
  start_date: date
  end_date: date
  reason: string (e.g., "Diwali closure")
}

interface BatchTiming {
  school_id: UUID
  timing_type: "morning" | "afternoon" | "evening" | "weekend"
  is_offered: boolean
}
```

### 7.4 API Endpoints (School Management Module)

**Profile Management**
```
GET    /api/schools/{school_id}              — Get full school profile
PUT    /api/schools/{school_id}              — Update school profile
PATCH  /api/schools/{school_id}              — Partial update
POST   /api/schools/{school_id}/photos       — Upload photo
DELETE /api/schools/{school_id}/photos/{id}  — Delete photo
```

**Settings**
```
GET    /api/schools/{school_id}/settings     — Get settings
PUT    /api/schools/{school_id}/settings     — Update settings
GET    /api/schools/{school_id}/api-keys     — Get API keys
POST   /api/schools/{school_id}/api-keys/regenerate — New key
```

**Team Management**
```
GET    /api/schools/{school_id}/team         — List team members
POST   /api/schools/{school_id}/team/invite  — Send invitation
DELETE /api/schools/{school_id}/team/{user_id} — Remove member
```

**Subscription**
```
GET    /api/schools/{school_id}/subscription — Get current plan
POST   /api/schools/{school_id}/subscription/upgrade — Change plan
GET    /api/schools/{school_id}/billing      — Get invoices
```

**Dashboard/Analytics**
```
GET    /api/schools/{school_id}/dashboard    — Dashboard metrics
GET    /api/schools/{school_id}/audit-log    — Audit trail
```

### 7.5 OpenAPI Spec Stub

```yaml
paths:
  /schools/{school_id}:
    get:
      summary: Get school profile
      parameters:
        - name: school_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
      responses:
        200:
          description: School profile
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/School'
        404:
          description: School not found
        403:
          description: Unauthorized
    
    put:
      summary: Update school profile
      parameters:
        - name: school_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              properties:
                legal_business_name:
                  type: string
                description:
                  type: string
                service_areas:
                  type: array
                  items:
                    type: string
      responses:
        200:
          description: School updated
        400:
          description: Validation error
        403:
          description: Unauthorized
```

---

## 8. Integration Points with Future Modules

### 8.1 Preparation for Phase 4 (Monetization)

**In Phase 3, we prepare:**
- Subscription tier entity (fields present, no UI for selection yet)
- Billing/invoice table structure
- API key generation infrastructure

**Phase 4 will add:**
- Upgrade/downgrade UI flow
- Payment method management
- Invoice generation and download
- Featured listing controls (using subscription tier)

### 8.2 Preparation for Phase 5 (Instructor Management)

**In Phase 3, we prepare:**
- Team member user type concept (owner/admin roles)
- RBAC system at API level
- School context in all API responses

**Phase 5 will add:**
- Instructor role and permissions
- Instructor authentication flow
- Instructor team roster UI (separate from admin team)
- Instructor availability settings UI

**Key boundary:** 
- Phase 3 = Owner + Admin management
- Phase 5 = Instructor management (separate section of dashboard)

### 8.3 Preparation for Phase 7 (Learner Management)

**In Phase 3, we prepare:**
- School context requirement (all learners belong to a school)
- Lead conversion hook (inquiry → learner, Phase 2 onward)
- Multi-school learner support at schema level

**Phase 7 will add:**
- Learner profile management
- Document management
- Learner-to-trainer assignment UI

---

## 9. Frontend Architecture

### 9.1 New Routes (School Management)

```
/dashboard/school/profile           — Edit school profile
/dashboard/school/settings          — Edit settings
/dashboard/school/operations        — Operations dashboard (home)
/dashboard/school/team              — Manage admins
/dashboard/school/subscription      — View & manage subscription
/dashboard/school/audit-log         — View audit trail
/dashboard/school/api-keys          — API key management (Phase 4)
```

### 9.2 New Components

```
SchoolProfileForm              — Edit profile fields
OperatingHoursEditor          — Set hours + closures
BatchTimingCheckbox           — Vehicle/training selection
ProfileCompletenessBar        — Progress indicator
TeamMemberTable               — List admins
InviteAdminModal              — Send invitation
SubscriptionCard              — Plan display
PlanUpgradeModal              — Change subscription
AuditLogTable                 — View audit events
DashboardMetricsCard          — Key stats widget
AlertBanner                   — Operational alerts
```

### 9.3 State Management (Zustand)

```typescript
schoolStore
  - school (full profile)
  - settings (full settings)
  - team (array of admin users)
  - subscription (current plan)
  - loading / error states
  - methods: fetchSchool, updateProfile, addTeamMember, etc.
```

### 9.4 Permissions Middleware

```typescript
// Protect routes by role
withSchoolAuth(component, requiredRole = "admin")
  - checks session
  - verifies user is school owner/admin
  - redirects to login if not authorized

// API requests include school context
fetchSchoolAPI(endpoint, {school_id, user_id, role})
  - server validates user has permission
  - returns 403 if unauthorized
```

---

## 10. Phase Boundaries (What's NOT in Phase 3)

### ❌ Not Including: Google Business Integration
- **Reason:** Requires school profile to be stable first
- **Phase:** Phase 4 (multi-step rollout)
- **What Phase 3 prepares:** API key infrastructure, webhook endpoints

### ❌ Not Including: Instructor Management
- **Reason:** School operations must be foundation first
- **Phase:** Phase 5
- **What Phase 3 prepares:** RBAC system, school context requirement

### ❌ Not Including: Learner Management
- **Reason:** Depends on both school + instructor context
- **Phase:** Phase 7
- **What Phase 3 prepares:** School owner/admin capability, subscription tiers

### ❌ Not Including: Messaging System
- **Reason:** Advanced communication layer
- **Phase:** Phase 9
- **What Phase 3 prepares:** Contact preference settings

### ❌ Not Including: Scheduling/Calendar
- **Reason:** Depends on instructor context
- **Phase:** Phase 5/6
- **What Phase 3 prepares:** Operating hours data structure

---

## 11. Success Metrics (Phase 3 Exit Criteria)

### Quantitative
- ✓ 100% of schools have profile completeness > 60%
- ✓ > 70% of schools add team members (at least 1 admin)
- ✓ 100% of schools view dashboard at least once
- ✓ Audit logging tracks 100% of administrative actions
- ✓ < 0.1% API errors on school endpoints

### Qualitative
- ✓ Schools report ease of profile management (NPS > 7)
- ✓ No data integrity issues in audit logs
- ✓ RBAC system prevents unauthorized access (security review pass)
- ✓ API contracts match Instructor/Learner PRD expectations
- ✓ Subscription tier logic ready for Phase 4 monetization

---

## 12. Implementation Notes

### Tech Stack (Continues from Phase 0)
- **Frontend:** React + Vite + TailwindCSS + Zustand
- **Backend:** Express + PostgreSQL + Drizzle ORM
- **Auth:** Unified JWT + session (built in Phase 0)
- **Audit:** PostgreSQL event table + JSON logging
- **File Storage:** DigitalOcean Spaces (for profile photos)

### Migration Path (From Current Codebase)
1. **Week 1:** Extend school table with new fields (completeness score, settings)
2. **Week 2:** Build settings entity, team/admin relationship
3. **Week 3:** Implement RBAC middleware, audit logging
4. **Week 4:** Build profile/settings forms (frontend)
5. **Week 5:** Dashboard metrics, subscription widget
6. **Week 6:** Testing, QA, launch

### Rollback Strategy
- Feature flags for school management module (can disable if issues)
- Audit log immutability (never delete, only archive)
- Soft delete for schools (not permanently removed)

---

## 13. Open Questions for Refinement

1. **Multi-branch expansion (future):** Should we prepare schema for branches in Phase 3 or defer?
2. **School logo requirements:** Minimum dimensions, DPI, file size limits?
3. **Team member invitations:** Can owner invite someone already signed up? Auto-link or manual?
4. **Subscription renewal:** Auto-renew or manual payment required each month?
5. **Audit log retention:** Default 2 years — should schools customize?

---

## 14. Success Story

**School Owner Experience (Post-Phase 3):**

> "I sign into DriveIQ, see my dashboard showing 45 inquiries this month with a 22% conversion rate. I notice my profile is 72% complete, so I add the missing photos and update my service area. I invite my manager to the platform — they get an email, click the link, and can now help manage inquiries. I check my subscription (Growth Plan, renews 30 Jan) and see I'm eligible for Instructor Management once my team grows. Everything I need is here — no more spreadsheets or WhatsApp groups."

---

## Conclusion

School Management is the **operational foundation** that transforms schools from passive marketplace listings to active platform operators. It establishes school-centric data ownership, team access control, and visibility into business metrics — prerequisites for instructor and learner management in subsequent phases.

**Phase 3 delivers:**
✓ Schools control their destiny (profile, settings, team)
✓ Platform has visibility (audit logs, metrics)
✓ Foundation for monetization (subscription tier ready)
✓ Preparation for instructor/learner modules
