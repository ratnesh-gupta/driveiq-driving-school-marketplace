# Integration Design Document

## Instructor ↔ Learner ↔ School Data & Workflow Model

**Version:** 1.0  
**Date:** January 2026  
**Status:** Design Specification  
**Scope:** Phase 5 (Instructor Mgmt) + Phase 7 (Learner Mgmt) Integration  
**Applies To:** Phases 5, 6, 7, 8, 9, 10

---

## Executive Summary

This document defines:

1. **Multi-school Instructor Mapping** — How instructors relate to schools
2. **Instructor → Learner Assignment** — How schools assign learners to trainers
3. **Schedule & Vehicle Assignment** — How schools manage trainer availability
4. **Data Isolation & Privacy** — What each role can see
5. **Learner Multi-registration** — Learners registered under multiple schools
6. **Instructor Career Progression** — Instructors becoming school owners
7. **Transition States** — Instructors moving between schools or becoming inactive

---

## 1. Core Data Relationships

### 1.1 School ↔ Instructor Relationship (1:1 per Active Mapping)

**Rule:** An instructor can only be actively mapped to ONE school at a time.

```text
School A  ←→  Instructor X (currently active)
                    ↓ (instructor leaves)
School A  ←→  Instructor X (marked inactive)
                    ↓ (instructor joins School B)
School B  ←→  Instructor X (now active)
```

**Data Model:**

```typescript
interface InstructorSchoolMapping {
  id: UUID (primary key)
  instructor_id: UUID (foreign key → users table)
  school_id: UUID (foreign key → schools table)
  
  // Status
  status: "active" | "inactive" | "suspended"
  
  // Tenure
  joined_date: timestamp
  left_date: timestamp | null (if inactive/left)
  reason_left: string | null ("better opportunity", "relocated", "fired", etc.)
  
  // Role (for future multi-role support)
  role: "instructor" | "admin" (future: can have both)
  
  created_at: timestamp
  updated_at: timestamp
}
```

**Example:**

```
Instructor: "Rajesh Patil" (user_id: 456)

Mapping 1:
  school_id: 100 (DriveRight Academy)
  status: "inactive"
  joined_date: 2024-01-01
  left_date: 2025-06-30
  reason_left: "relocated to Bangalore"

Mapping 2 (current):
  school_id: 101 (QuickDrive School)
  status: "active"
  joined_date: 2025-07-01
  left_date: null
  reason_left: null
```

### 1.2 Instructor ↔ Learner Relationship (Many-to-Many per School)

**Rule:** An instructor assigned to a school can train multiple learners at that school.

```text
Instructor X (at School A)
    ↓
    ├─ Learner 1
    ├─ Learner 2
    └─ Learner 3

Instructor Y (at School A)
    ↓
    └─ Learner 1 (different learner)
```

**Data Model:**

```typescript
interface LearnerInstructorAssignment {
  id: UUID (primary key)
  learner_id: UUID (foreign key → users table)
  instructor_id: UUID (foreign key → users table)
  school_id: UUID (foreign key → schools table)
  
  // Vehicle assignment
  vehicle_id: UUID | null (which vehicle for this training)
  vehicle_name: string (e.g., "Swift ZXi - DL-1A2345")
  
  // Schedule
  start_date: date (when training begins)
  expected_completion_date: date | null
  actual_completion_date: date | null (filled when training ends)
  
  // Status
  status: "assigned" | "active" | "completed" | "cancelled"
  
  // Metadata
  package_id: UUID (which training package)
  assigned_date: timestamp
  completed_date: timestamp | null
  
  created_at: timestamp
  updated_at: timestamp
}
```

**Example:**

```
School A assignments to Instructor X:
  - Learner: Amit Singh
    Vehicle: Swift ZXi (DL-1A2345)
    Start: 2026-01-20
    Status: active
  
  - Learner: Priya Desai
    Vehicle: Hyundai i20 (DL-5K9012)
    Start: 2026-02-01
    Status: assigned (not yet started)

School A assignments to Instructor Y:
  - Learner: Vikram Nair
    Vehicle: Swift ZXi (DL-1A2345)
    Start: 2026-01-15
    Status: completed
```

### 1.3 Learner Multi-Registration (Across Schools)

**Rule:** A learner can be registered with multiple schools simultaneously or sequentially.

```text
Learner: "Anjali Sharma"
    ├─ School A (primary: driving lessons)
    ├─ School B (secondary: defensive driving course)
    └─ School C (future: bike training)
```

**Data Model:**

```typescript
interface LearnerSchoolRegistration {
  id: UUID (primary key)
  learner_id: UUID (foreign key → users table)
  school_id: UUID (foreign key → schools table)
  
  // Registration details
  registration_date: timestamp
  status: "active" | "completed" | "paused" | "dropped"
  
  // Vehicle type for this school
  vehicle_type: "car_manual" | "car_automatic" | "motorcycle" | "scooter"
  
  // Package/course
  package_id: UUID (training package at this school)
  
  // Training progress
  lessons_completed: number
  progress_percentage: number (0-100)
  
  completion_date: date | null (if status = completed)
  
  created_at: timestamp
  updated_at: timestamp
}
```

**Example:**

```
Learner: Anjali Sharma (user_id: 789)

Registration 1:
  school_id: 100 (DriveRight Academy)
  status: "active"
  vehicle_type: "car_automatic"
  progress_percentage: 45%
  
Registration 2:
  school_id: 102 (Advanced Driving Institute)
  status: "active"
  vehicle_type: "motorcycle"
  progress_percentage: 20%
  
Registration 3:
  school_id: 101 (QuickDrive School)
  status: "completed"
  completion_date: 2025-12-15
```

---

## 2. Scheduling & Vehicle Management

### 2.1 Vehicle Assignment to Instructor

**Rule:** A vehicle is owned by a school and assigned to an instructor for training sessions.

```text
School A
  ├─ Vehicle 1 (Swift ZXi - DL-1A2345)
  │   └─ Assigned to: Instructor X
  │       └─ Sessions: Mon, Wed, Fri 2-4pm
  │
  ├─ Vehicle 2 (Hyundai i20 - DL-5K9012)
  │   └─ Assigned to: Instructor Y
  │       └─ Sessions: Tue, Thu 10am-12pm
  │
  └─ Vehicle 3 (Inactive - DL-9Z8765)
      └─ Assigned to: None (under maintenance)
```

**Data Model:**

```typescript
interface Vehicle {
  id: UUID (primary key)
  school_id: UUID (foreign key → schools table)
  
  // Vehicle details
  registration_number: string (e.g., "DL-1A2345")
  brand_model: string (e.g., "Swift ZXi")
  vehicle_type: "car_manual" | "car_automatic" | "motorcycle" | "scooter"
  fuel_type: "petrol" | "diesel" | "electric"
  year: number
  
  // Current assignment
  assigned_instructor_id: UUID | null (who's using it)
  assigned_date: date | null
  
  // Status
  status: "active" | "maintenance" | "inactive"
  
  // Documents
  rc_expiry_date: date (Registration Certificate)
  insurance_expiry_date: date
  pollution_cert_expiry_date: date
  
  created_at: timestamp
  updated_at: timestamp
}

interface InstructorVehicleAssignment {
  id: UUID (primary key)
  instructor_id: UUID
  vehicle_id: UUID
  school_id: UUID
  
  assigned_date: date
  unassigned_date: date | null (if no longer using)
  
  notes: string (e.g., "Primary vehicle for morning batches")
}
```

### 2.2 Session Scheduling

**Rule:** School admin creates sessions (date, time, vehicle, instructor, learner).

```text
Session Creation Flow:
  School Admin selects:
    → Instructor X
    → Learner Y
    → Date: 20 Jan 2026
    → Time: 2pm - 4pm
    → Vehicle: Swift ZXi (DL-1A2345)
    → Type: "Practical - Parking"
    
System checks:
  ✓ Instructor X mapped to this school?
  ✓ Learner Y mapped to this school?
  ✓ Vehicle available at that time?
  ✓ Instructor available (no conflicting session)?
  ✓ Learner available (no conflicting session)?
  
If all pass:
  → Session created
  → Notifications sent to instructor + learner
  → Calendar updated
```

**Data Model:**

```typescript
interface TrainingSession {
  id: UUID (primary key)
  school_id: UUID
  instructor_id: UUID
  learner_id: UUID
  vehicle_id: UUID
  
  // Schedule
  session_date: date
  session_time_start: time
  session_time_end: time
  duration_minutes: number
  
  // Session details
  session_type: "practical" | "theory" | "test_prep"
  focus_area: string (e.g., "Parking", "Highway Driving")
  
  // Status
  status: "scheduled" | "completed" | "cancelled" | "rescheduled"
  
  // Attendance & outcome
  instructor_attended: boolean | null
  learner_attended: boolean | null
  notes: string (trainer notes after session)
  
  created_at: timestamp
  updated_at: timestamp
  completed_at: timestamp | null
}
```

### 2.3 Conflict Detection & Prevention

**Conflict Rules:**

```text
Rule 1: Instructor cannot have overlapping sessions
  Instructor X booked 2-4pm on 20 Jan
    → Cannot schedule another session 2-4pm (or overlapping time) same day

Rule 2: Vehicle cannot have overlapping assignments
  Swift ZXi (DL-1A2345) booked 2-4pm on 20 Jan with Instructor X
    → Cannot book same vehicle for Instructor Y at 2-4pm

Rule 3: Learner cannot have overlapping sessions
  Learner Y booked 2-4pm on 20 Jan with Instructor X
    → Cannot schedule another session overlapping that time
    
    BUT: Learner Y CAN have sessions at different schools same day
         (e.g., 2-4pm at School A, 5-7pm at School B)

Rule 4: Vehicle documents must be valid
  Requires RC, Insurance, Pollution cert all valid
    → Session cannot be created if any document expired

Rule 5: Instructor must be active at school
  Instructor's mapping status = "active"
    → Cannot schedule if status = "inactive" or left school
```

**Implementation:**

```typescript
// During session creation
async function validateSessionCreation(
  instructor_id: UUID,
  learner_id: UUID,
  vehicle_id: UUID,
  school_id: UUID,
  session_date: date,
  start_time: time,
  end_time: time
): Promise<ValidationResult> {
  
  // Check 1: Instructor active at this school
  const instructorMapping = await db.InstructorSchoolMapping.findOne({
    instructor_id,
    school_id,
    status: "active"
  });
  if (!instructorMapping) return { valid: false, reason: "Instructor not active at this school" };
  
  // Check 2: Learner registered at this school
  const learnerReg = await db.LearnerSchoolRegistration.findOne({
    learner_id,
    school_id,
    status: "active"
  });
  if (!learnerReg) return { valid: false, reason: "Learner not registered at this school" };
  
  // Check 3: No instructor conflicts
  const instructorConflict = await db.TrainingSession.findOne({
    instructor_id,
    session_date,
    status: "scheduled",
    // Time overlap check: sessions overlap if start1 < end2 AND start2 < end1
    session_time_start: { $lt: end_time },
    session_time_end: { $gt: start_time }
  });
  if (instructorConflict) return { valid: false, reason: "Instructor has conflicting session" };
  
  // Check 4: No vehicle conflicts
  const vehicleConflict = await db.TrainingSession.findOne({
    vehicle_id,
    session_date,
    status: "scheduled",
    session_time_start: { $lt: end_time },
    session_time_end: { $gt: start_time }
  });
  if (vehicleConflict) return { valid: false, reason: "Vehicle not available at this time" };
  
  // Check 5: No learner conflicts at SAME school
  const learnerConflictSameSchool = await db.TrainingSession.findOne({
    learner_id,
    school_id,
    session_date,
    status: "scheduled",
    session_time_start: { $lt: end_time },
    session_time_end: { $gt: start_time }
  });
  if (learnerConflictSameSchool) return { valid: false, reason: "Learner has conflicting session at this school" };
  
  // Check 6: Vehicle documents valid
  const vehicle = await db.Vehicle.findOne({ id: vehicle_id });
  if (vehicle.rc_expiry_date < today()) return { valid: false, reason: "Vehicle RC expired" };
  if (vehicle.insurance_expiry_date < today()) return { valid: false, reason: "Vehicle insurance expired" };
  
  return { valid: true };
}
```

---

## 3. Data Visibility & Access Control

### 3.1 School Owner/Admin Visibility

**A school owner/admin can see:**

```text
✓ All instructors mapped to their school (active + inactive history)
✓ All learners registered at their school
✓ All sessions scheduled at their school
✓ All vehicles owned by their school
✓ All inquiries → converted leads at their school

✗ Instructors/learners/sessions at OTHER schools
✗ Another school's vehicle fleet
✗ Another school's business data
```

**API Permission Check:**

```typescript
// GET /api/schools/{school_id}/instructors
async function getSchoolInstructors(school_id, user) {
  // Verify user owns/manages this school
  const school = await db.School.findOne({ id: school_id });
  if (school.owner_user_id !== user.id && 
      !school.admin_user_ids.includes(user.id)) {
    throw new ForbiddenError("Not authorized to view this school's data");
  }
  
  // Return only instructors mapped to this school
  const mappings = await db.InstructorSchoolMapping.find({
    school_id,
    // Include both active and inactive (for history)
  });
  
  return mappings;
}
```

### 3.2 Instructor Visibility

**An instructor can see:**

```text
✓ Own profile and employment details
✓ Own availability/schedule at current school
✓ Learners assigned to them (at current school only)
✓ Sessions they're scheduled for
✓ Own training notes + performance metrics

✗ Other instructors at same school
✗ School's admin users
✗ School's business settings
✗ Learners not assigned to them
✗ Learners at other schools
✗ Instructors at other schools
✗ School's financial/billing data
```

**Example:**

```
Instructor Rajesh (at School A):
  ✓ Can see: Learner 1, Learner 2, Learner 3 (assigned to him)
  ✓ Can see: Sessions for 20 Jan, 21 Jan, 23 Jan
  ✗ Cannot see: School A's other instructor (Priya)
  ✗ Cannot see: Learners assigned to Priya
  ✗ Cannot see: Learner 4 (registered but not assigned to him)
  
If Rajesh moves to School B:
  ✗ Cannot see: Learners at School A anymore
  ✓ Can see: New learners assigned to him at School B
```

**API Permission Check:**

```typescript
// GET /api/instructors/{instructor_id}/sessions
async function getInstructorSessions(instructor_id, user) {
  // Verify this is the instructor's own session request
  if (user.id !== instructor_id) {
    throw new ForbiddenError("Can only view your own sessions");
  }
  
  // Get instructor's current school mapping
  const mapping = await db.InstructorSchoolMapping.findOne({
    instructor_id,
    status: "active"
  });
  
  if (!mapping) {
    throw new NotFoundError("Instructor not currently mapped to any school");
  }
  
  // Return only sessions at current school
  const sessions = await db.TrainingSession.find({
    instructor_id,
    school_id: mapping.school_id
  });
  
  return sessions;
}
```

### 3.3 Learner Visibility

**A learner can see:**

```text
✓ Own profile and registrations
✓ Sessions they're scheduled for (at all registered schools)
✓ Instructors assigned to them (at each school)
✓ Own training progress (at each school)
✓ Own documents and completeness
✓ Marketplace: all schools (to browse before registering elsewhere)

✗ Other learners' data
✗ School admin data
✗ School's operational metrics
✗ Other instructors' schedules
```

**Example:**

```
Learner Anjali (registered at School A and School B):
  ✓ Can see: Session with Instructor X at School A on 20 Jan
  ✓ Can see: Session with Instructor Y at School B on 22 Jan
  ✓ Can see: Progress at School A (45% complete)
  ✓ Can see: Progress at School B (20% complete)
  ✗ Cannot see: School A's instructor list
  ✗ Cannot see: School A's vehicle details
```

---

## 4. Instructor Career Progression

### 4.1 Scenario: Instructor Becomes School Owner

**Current State:**
```
Instructor: "Rajesh Patil" (user_id: 456)
  - Mapped to School A
  - Role: instructor
  
School A: owned by "Amit Singh"
```

**Transition Path:**

```
Step 1: Rajesh leaves School A
  - InstructorSchoolMapping.status = "inactive"
  - InstructorSchoolMapping.left_date = today
  - Rajesh creates own school (School B)
  - School B created with owner_user_id = 456

Step 2: Rajesh is now owner
  - user.role = "school_owner" (or can have multiple roles)
  - Can add instructors to School B
  - Can create learners at School B
  - Becomes admin of School B

Before Transfer:
  - Platform admin can reassign Rajesh's learners to another instructor
  - Or learners can choose to continue with new instructor at same school
  - Or switch to Rajesh's new school
```

**Data Model Support:**

```typescript
// User table extended
interface User {
  id: UUID
  email: string
  phone: string
  
  // Role(s) — can have multiple
  roles: ("school_owner" | "school_admin" | "instructor" | "learner")[]
  
  // Profile type
  user_type: "individual" | "school" (future: schools as entities)
  
  // Bio
  name: string
  photo_url: string | null
  
  created_at: timestamp
}

// Example: Rajesh (instructor) becomes owner
User: Rajesh
  roles: ["instructor", "school_owner"]
  user_type: "individual"
  schools_owned: [School B]
  schools_administering: [School B]
  schools_instructing: [School A (inactive), School B (active)]
```

### 4.2 Scenario: Instructor Moves Between Schools

**Current:**
```
Instructor X at School A (active)
  - Instructors assigned to Learners 1, 2, 3
```

**Moving to School B:**

```
Step 1: Instructor leaves School A
  - InstructorSchoolMapping(school_a).status = "inactive"
  - All sessions at School A end
  - Learners 1, 2, 3 notified: "Your trainer is no longer available"

Step 2: Instructor joins School B
  - InstructorSchoolMapping(school_b).status = "active"
  - New profile at School B
  - Assigned new learners (if any)

Step 3: Historical data preserved
  - Learners at School A still see past sessions with Instructor X
  - Learners at School A get new instructor (if continuing)
  - Learners cannot "follow" instructor to School B (data isolation)
```

---

## 5. Authentication & Session Management

### 5.1 Unified Authentication System

**Single login, multiple roles:**

```typescript
// User login
POST /api/auth/login
{
  "email": "rajesh@email.com",
  "password": "..."
}

// Response includes:
{
  "user": {
    "id": "456",
    "email": "rajesh@email.com",
    "roles": ["instructor", "school_owner"],
    "active_role": "instructor" // Current context
  },
  "token": "jwt...",
  "schools": [
    {
      "school_id": "100",
      "school_name": "School A",
      "role": "instructor" // Role at this school
    },
    {
      "school_id": "101",
      "school_name": "School B",
      "role": "school_owner" // Role at this school
    }
  ]
}
```

### 5.2 Role Switching (Same Session)

```typescript
// User can switch context without re-login
POST /api/auth/switch-role
{
  "target_school_id": "101",
  "target_role": "school_owner"
}

// New JWT issued with updated context
{
  "user": {
    "id": "456",
    "active_role": "school_owner",
    "active_school_id": "101"
  },
  "token": "jwt...(new)"
}

// Dashboard now shows School B (owner view) instead of School A (instructor view)
```

### 5.3 Instructor Onboarding (Invite Flow)

```text
School Admin clicks: [Add Instructor]
  ↓
Enters: instructor email, name, vehicle type skills
  ↓
System generates: invitation token (valid 7 days)
  ↓
Email sent: "You've been invited to join [School Name]"
  ↓
Instructor clicks link
  ↓
If NOT signed up:
    → Create account (email pre-filled, auto-verified)
    → Set password
    → Auto-join school as instructor
  ↓
If already signed up:
    → Login (if not already logged in)
    → Accept invitation
    → InstructorSchoolMapping created
  ↓
Instructor completes profile:
    → License number
    → Experience
    → Languages
    → Document uploads
  ↓
Status: "pending_approval" → School admin approves → "active"
```

---

## 6. Learner Multi-Registration Management

### 6.1 Learner Registration at Multiple Schools

**Allowed:**
```
Learner registers at School A (car manual training)
  ↓
Later, registers at School B (motorcycle training)
  ↓
Both registrations active simultaneously
  ↓
Each school sees only their registration
```

**Tracking:**
```typescript
interface LearnerSchoolRegistration {
  learner_id: UUID
  school_id: UUID
  status: "active" | "completed" | "paused" | "dropped"
  vehicle_type: "car_manual" | "motorcycle" // Different per school
  progress: number // Independent per school
}

// Example: Anjali registered at 2 schools
LearnerSchoolRegistration 1:
  learner_id: anjali_id
  school_id: school_a_id
  vehicle_type: "car_automatic"
  progress: 45%
  
LearnerSchoolRegistration 2:
  learner_id: anjali_id
  school_id: school_b_id
  vehicle_type: "motorcycle"
  progress: 20%
```

### 6.2 Learner Portal Shows All Registrations

```text
Anjali's Dashboard:

Registrations
┌─────────────────────────────────────┐
│ School A: Car Automatic             │
│ Status: Active (45% complete)       │
│ Trainer: Instructor X               │
│ Next Session: 20 Jan, 2pm           │
│ [View Details]                      │
├─────────────────────────────────────┤
│ School B: Motorcycle Training       │
│ Status: Active (20% complete)       │
│ Trainer: Instructor Y               │
│ Next Session: 22 Jan, 4pm           │
│ [View Details]                      │
├─────────────────────────────────────┤
│ School C: Defensive Driving         │
│ Status: Completed (15 Dec 2025)     │
│ Certificate: [Download]             │
└─────────────────────────────────────┘
```

---

## 7. Transition & Inactive States

### 7.1 Instructor Inactive States

**Possible states:**

```text
Status: "active"
  → Instructor currently training learners
  → Can be scheduled for new sessions
  → Visible to learners at this school

Status: "inactive"
  → Instructor has left school or on extended leave
  → Cannot be scheduled for NEW sessions
  → Existing sessions cancelled (learners notified)
  → Historical data preserved (past sessions visible)

Status: "suspended"
  → Temporary deactivation (e.g., pending verification)
  → Cannot be scheduled
  → Await admin review
```

### 7.2 Learner Inactive States

```text
Status: "active"
  → Learner actively training
  → Can see sessions, trainers, progress

Status: "paused"
  → Learner paused (e.g., medical, vacation)
  → Sessions not created during pause
  → Can resume without re-registering

Status: "completed"
  → Training completed
  → Can see certificate/progress report
  → Cannot schedule new sessions

Status: "dropped"
  → Learner left without completing
  → Cannot schedule new sessions
  → Can re-register later if desired
```

---

## 8. Data Isolation Examples

### 8.1 Example: School A Admin Queries

```typescript
// School A admin wants to see all their data

GET /api/schools/school_a_id/instructors
  Response: [Instructor X, Instructor Y] (active + inactive history)
  
GET /api/schools/school_a_id/learners
  Response: [Learner 1, Learner 2, Learner 3, Learner 5]
  (Learner 5 is shared with School B, but School A sees their own registration)
  
GET /api/schools/school_a_id/vehicles
  Response: [Vehicle A, Vehicle B, Vehicle C]
  (Only School A's vehicles)
  
GET /api/schools/school_a_id/sessions
  Response: [Session 1 on 20 Jan, Session 2 on 21 Jan, ...]
  (Only sessions at School A)

// What they CANNOT query
GET /api/schools/school_b_id/...
  Response: 403 Forbidden
  (No access to School B data)
```

### 8.2 Example: Instructor Queries

```typescript
// Instructor X (at School A) queries own data

GET /api/instructors/instructor_x_id/sessions
  Response: [Session 1 on 20 Jan at School A, Session 2 on 21 Jan at School A]
  (Only sessions at current school)
  
GET /api/instructors/instructor_x_id/learners
  Response: [Learner 1, Learner 2, Learner 3]
  (Only learners assigned to this instructor)
  
GET /api/instructors/instructor_x_id/school-info
  Response: { school_name: "School A", address: "...", phone: "..." }
  (Only current school info)

// After moving to School B
GET /api/instructors/instructor_x_id/sessions
  Response: [Sessions at School B only]
  (Previous School A sessions no longer visible)
```

### 8.3 Example: Learner Queries

```typescript
// Learner Anjali (registered at Schools A and B)

GET /api/learners/anjali_id/registrations
  Response: [
    { school_id: "a", progress: 45%, trainer: "X" },
    { school_id: "b", progress: 20%, trainer: "Y" }
  ]
  (Both schools visible)
  
GET /api/learners/anjali_id/sessions
  Response: [
    { date: "20 Jan", time: "2pm", school: "a", trainer: "X" },
    { date: "22 Jan", time: "4pm", school: "b", trainer: "Y" }
  ]
  (Sessions at both schools)
  
GET /api/learners/anjali_id/progress
  Response: [
    { school: "a", percentage: 45%, completed_lessons: [...] },
    { school: "b", percentage: 20%, completed_lessons: [...] }
  ]
  (Independent progress per school)

// Anjali CANNOT see
GET /api/schools/school_a_id/learners
  Response: 403 Forbidden
  (Not an admin at School A)
```

---

## 9. API Contract Changes & New Endpoints

### 9.1 Instructor School Mapping Endpoints

```yaml
POST /api/schools/{school_id}/instructors/invite
  Description: Invite instructor to school
  Body: { email, name, skills }
  Response: invitation_token, email_sent
  Auth: school_owner only

GET /api/schools/{school_id}/instructors
  Description: List instructors (active + inactive)
  Query: ?status=active|inactive|all
  Response: [{ id, name, status, joined_date, left_date, ... }]
  Auth: school_owner/admin

GET /api/instructors/{instructor_id}
  Description: Get instructor profile (if own profile or assigned learner)
  Response: instructor profile
  Auth: self or assigned learner

GET /api/instructors/{instructor_id}/sessions
  Description: Get instructor's sessions
  Query: ?date=YYYY-MM-DD, ?status=scheduled|completed
  Response: [sessions]
  Auth: self only (instructor)
```

### 9.2 Learner Registration Endpoints

```yaml
POST /api/schools/{school_id}/learners
  Description: Register learner at school (convert inquiry → learner)
  Body: { email, phone, vehicle_type, package_id }
  Response: learner_id, registration_id
  Auth: school_owner/admin

GET /api/learners/{learner_id}/registrations
  Description: Get all school registrations for learner
  Response: [{ school_id, school_name, status, progress, ... }]
  Auth: self (learner)

GET /api/schools/{school_id}/learners
  Description: List learners registered at school
  Query: ?status=active|completed|dropped
  Response: [learners with progress]
  Auth: school_owner/admin

PUT /api/learners/{learner_id}/registrations/{registration_id}
  Description: Update learner registration (pause, drop, etc.)
  Body: { status: "paused"|"dropped"|"active" }
  Auth: self or school_admin
```

### 9.3 Session & Scheduling Endpoints

```yaml
POST /api/schools/{school_id}/sessions
  Description: Create training session
  Body: { 
    instructor_id, learner_id, vehicle_id, 
    date, start_time, end_time, 
    focus_area 
  }
  Response: session_id (with conflict validation)
  Auth: school_owner/admin

GET /api/schools/{school_id}/sessions
  Description: List sessions at school
  Query: ?date=YYYY-MM-DD, ?instructor_id=..., ?learner_id=...
  Response: [sessions]
  Auth: school_owner/admin

GET /api/instructors/{instructor_id}/sessions
  Description: Get instructor's sessions
  Response: [sessions at current school]
  Auth: self

PATCH /api/sessions/{session_id}
  Description: Update session (reschedule, mark attended, add notes)
  Body: { status, instructor_attended, learner_attended, notes }
  Auth: school_admin or instructor (for notes only)
```

---

## 10. Conflict Resolution & Edge Cases

### 10.1 What if Learner Drops at School A but Trainer is Reassigned?

```
Scenario:
  Learner Y was assigned to Instructor X at School A
  Learner Y status becomes "dropped"
  → Instructor X's assignment to Learner Y remains in history
  → Trainer might be assigned to new learner to fill slot

Handling:
  ✓ Show learner as "dropped" in instructor's view
  ✓ Trainer can take on another learner
  ✓ Historical sessions remain visible
```

### 10.2 What if School Becomes Inactive?

```
Scenario:
  School A becomes inactive/suspended
  → All instructors at School A: mapping status = "inactive"
  → All learners at School A: registration status = "paused"
  → All sessions cancelled, learners notified

Recovery:
  School reactivates:
    → Admin manually resets instructor/learner statuses
    → Reschedule sessions
```

### 10.3 What if Instructor is Suspended?

```
Scenario:
  Instructor X under investigation
  → Mapping status = "suspended"
  → Cannot schedule new sessions
  → Existing sessions: school admin must reassign or cancel

Options for school admin:
  A) Reassign learners to another trainer
  B) Cancel sessions (refund learner)
  C) Pause learner registrations (temporarily)
```

### 10.4 What if Learner Leaves and Rejoins?

```
Scenario:
  Learner Z completes car training at School A (status = "completed")
  Later, wants to do motorcycle training at School A
  
Handling:
  ✓ Create new registration (same learner, same school, different vehicle_type)
  ✓ Progress independent from first registration
  ✓ Can assign different instructor
  ✓ First registration remains in history
```

---

## 11. Testing Strategy (Integration Tests)

### 11.1 Test Scenarios

```gherkin
Scenario: Instructor cannot see learners from other trainers
  Given Instructor X assigned to Learner 1 and Learner 2 at School A
  And Instructor Y assigned to Learner 3 at School A
  When Instructor X queries /api/instructors/{X}/learners
  Then Response contains [Learner 1, Learner 2] only
  And Response does NOT contain Learner 3

Scenario: School admin cannot see another school's data
  Given School A with Admin A
  And School B with Admin B
  When Admin A queries /api/schools/school_b_id/learners
  Then Response is 403 Forbidden

Scenario: Learner can see sessions at multiple schools
  Given Learner Z registered at School A and School B
  When Learner Z queries /api/learners/{Z}/sessions
  Then Response contains:
    - Sessions at School A with Instructor X
    - Sessions at School B with Instructor Y

Scenario: Session creation fails if instructor not active at school
  Given Instructor X marked inactive at School A
  When Admin tries to create session with Instructor X at School A
  Then Response is 400 Bad Request: "Instructor not active at this school"

Scenario: Instructor moves to new school
  Given Instructor X active at School A (with Learner 1, 2)
  When Instructor X's mapping at School A = "inactive"
  And new mapping created at School B
  Then:
    - Instructor X cannot see School A learners anymore
    - School A learners need new instructor assignment
    - Instructor X can accept learners at School B
```

---

## 12. Rollout & Migration Plan

### 12.1 Phase 5 (Instructor Management) Implementation

```
Week 1-2: Data model
  - Create InstructorSchoolMapping table
  - Create TrainingSession table
  - Add instructor fields to users table

Week 3-4: Auth & Onboarding
  - Implement instructor login
  - Invite flow with token
  - Role switching logic

Week 5: Dashboard
  - Instructor calendar view
  - Basic session creation
  - Learner roster (read-only, Phase 7 adds full mgmt)

Week 6: Testing & Launch
  - Integration tests
  - Conflict detection tests
  - API contract validation
```

### 12.2 Phase 7 (Learner Management) Implementation

```
Week 1-2: Learner profile
  - LearnerSchoolRegistration table
  - Learner portal views

Week 3-4: Assignment workflow
  - Assign learner → trainer → vehicle
  - Session creation (full workflow)
  - Conflict validation

Week 5: Learner-facing features
  - Learner dashboard
  - Schedule view
  - Document upload

Week 6: Testing & Launch
  - Multi-school registration tests
  - Isolation tests
  - End-to-end workflows
```

---

## 13. Conclusion

This document establishes:

✓ **Instructor ↔ School:** 1:1 mapping, can move between schools  
✓ **Instructor ↔ Learner:** Many-to-many per school, cannot follow across schools  
✓ **Learner ↔ School:** Many-to-many, learners can register at multiple schools  
✓ **Vehicle ↔ Instructor ↔ Session:** School controls allocation and scheduling  
✓ **Data Isolation:** Each school/instructor/learner sees only their relevant data  
✓ **Career Progression:** Instructors can become owners or move schools  
✓ **Conflict Prevention:** System prevents double-booking of instructors, vehicles, learners  
✓ **Multi-registration:** Learners can train at multiple schools independently  

The result is a flexible, scalable system supporting:
- Schools managing multiple instructors
- Instructors working at one school at a time (but moving between schools)
- Learners training at multiple schools simultaneously
- Full data isolation between schools and users
